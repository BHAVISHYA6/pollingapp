const express = require('express');
const cors = require('cors');
const app = express();

// Middleware
app.use(cors({
  origin:[],
  credentials: true,
  allowedHeaders: ['Content-Type', 'Authorization', 'x-auth-token'],
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
}));

app.use(express.json());

// Routes
app.use('/api/polls', require('./routes/polls'));
app.use('/api/auth', require('./routes/auth'));

// Default route (only for "/")
app.get('/', (req, res) => {
  res.send('Hello World!');
});

module.exports = app;
