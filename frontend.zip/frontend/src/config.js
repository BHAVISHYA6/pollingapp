const API_BASE_URL = 'https://e5uky98qyk.execute-api.ap-south-1.amazonaws.com/prod';

export default API_BASE_URL;